// Listener für Nachrichten vom Popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "collectData") {
    // URL und kompletten HTML-Code der aktuellen Seite erfassen
    const url = window.location.href;
    const html = document.documentElement.outerHTML;
    
    // Den Button mit der gesuchten Klasse suchen
    const phoneButton = document.querySelector('.JuVrD.FWtU1.drxl5.vfGGm');
    if (phoneButton) {
      // Verzögerung einbauen, damit die Daten gesammelt werden, bevor eventuell eine Navigation erfolgt
      setTimeout(() => {
        phoneButton.click();
        console.log("✔️ Button gefunden und geklickt!");
      }, 500);
    } else {
      console.log("❌ Button nicht gefunden.");
    }
    
    // Die gesammelten Daten an das Popup zurücksenden
    sendResponse({ result: { url, html } });
  }
  // Hinweis: Da die Antwort synchron erfolgt, ist kein return true notwendig.
});
