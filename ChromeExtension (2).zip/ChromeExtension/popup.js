const socket = new WebSocket("ws://127.0.0.1:8080");

socket.onopen = function () {
    console.log("Verbindung mit C# WebSocket-Server hergestellt.");
};

socket.onerror = function (error) {
    console.error("WebSocket-Fehler:", error);
};

document.getElementById("klickButton").addEventListener("click", function () {
    // Code im aktuellen Tab ausführen
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
        if (tabs.length > 0) {
            let tabId = tabs[0].id;

			console.log("HS");

            chrome.scripting.executeScript({
                target: { tabId: tabId },
                function: handlePage
            }, (results) => {
                if (chrome.runtime.lastError) {
                    console.error("Fehler beim Ausführen des Scripts:", chrome.runtime.lastError.message);
                } else if (results && results[0] && results[0].result) {
                    let data = results[0].result;
					
                    if (socket.readyState === WebSocket.OPEN) {
                        socket.send(JSON.stringify(data));
                        console.log("Daten gesendet:", data);
                    } else {
                        console.log("WebSocket ist nicht verbunden.");
                    }
                }
            });
        }
    });
});

// Funktion, die auf der Webseite ausgeführt wird
function handlePage() {
    let url = window.location.href;
    
    // Button suchen
    let phoneButton = document.querySelector('.JuVrD.FWtU1.drxl5.vfGGm');
    if (phoneButton) {
        phoneButton.click();
        console.log("📞 Button wurde geklickt!");

        // 1 Sekunde warten, bevor die HTML-Daten gesammelt werden
        setTimeout(() => {
            let html = document.documentElement.outerHTML;
            return { url: url, html: html };
        }, 1000);

    } else {
        console.log("❌ Kein Button gefunden!");
        return { url: url, html: document.documentElement.outerHTML };
    }
}
